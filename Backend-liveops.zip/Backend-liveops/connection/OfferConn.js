const mongoose=require("mongoose")

 
async function OfferConnect(){
    await mongoose.connect("mongodb://localhost/offer")
    console.log("mongodb connected Offerconnection")
}
OfferConnect()


const Schema=mongoose.Schema
const ObjectId=Schema.ObjectId

const AdminSchema=new Schema({
    email:String,
    password:{type:String,min:5,max:16}
})

const adminmodel=mongoose.model("admincoll",AdminSchema)

module.exports=adminmodel